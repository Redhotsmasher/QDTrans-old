#ifndef QDTRANS_PRINTTREE
#define QDTRANS_PRINTTREE
#include <clang-c/Index.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "common.h"

void printTree(struct nodeTree* inTree);

#endif /* QDTRANS_PRINTTREE */
